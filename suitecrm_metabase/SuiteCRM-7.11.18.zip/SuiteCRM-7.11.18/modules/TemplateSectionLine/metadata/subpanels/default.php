<?php
$module_name='TemplateSectionLine';
$subpanel_layout = array(
  'top_buttons' =>
  array(
    0 =>
    array(
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 =>
    array(
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'TemplateSectionLine',
    ),
  ),
  'where' => '',
  'list_fields' =>
  array(
    'grp' =>
    array(
      'type' => 'varchar',
      'vname' => 'LBL_GRP',
      'width' => '10%',
      'default' => true,
    ),
    'name' =>
    array(
      'vname' => 'LBL_NAME',
      'widget_class' => 'SubPanelDetailViewLink',
      'width' => '45%',
      'default' => true,
    ),
    'description' =>
    array(
      'type' => 'text',
      'vname' => 'LBL_DESCRIPTION',
      'sortable' => false,
      'width' => '10%',
      'default' => true,
    ),
    'edit_button' =>
    array(
      'vname' => 'LBL_EDIT_BUTTON',
      'widget_class' => 'SubPanelEditButton',
      'module' => 'TemplateSectionLine',
      'width' => '4%',
      'default' => true,
    ),
    'remove_button' =>
    array(
      'vname' => 'LBL_REMOVE',
      'widget_class' => 'SubPanelRemoveButton',
      'module' => 'TemplateSectionLine',
      'width' => '5%',
      'default' => true,
    ),
  ),
);
